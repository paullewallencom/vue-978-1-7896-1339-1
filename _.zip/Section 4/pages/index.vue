<template>
  <article-list />
</template>

<script>
import ArticleList from '@/components/ArticleList'

export default {
  components: {
    ArticleList,
  },
}
</script>
